# LRN fit

A simple calorie-counting web app built with plain HTML, CSS, and JavaScript.

## How to Run It

Open `index.html` in your browser.

## What It Does

- Sets a daily calorie goal.
- Saves a profile with name, height, current weight, and goal weight.
- Saves a daily health diary for each selected date.
- Sets editable protein, carbs, and fat goals from the daily calorie goal.
- Adds foods with calorie amounts.
- Adds protein, carbs, and fat for each food.
- Includes a simple AI-style macro helper inside the app.
- Adds exercise as cardio or weightlifting.
- Stores workout notes and calories burned.
- Generates suggested AMRAP and circuit workouts from calories, minutes, equipment, workout type, and body focus.
- Regenerates a different workout when the first suggestion does not fit.
- Adds a history tab with a monthly calendar.
- Lets you click a calendar day to review and edit that date.
- Shows total calories logged.
- Shows calories burned and net calories.
- Shows calories remaining or over goal after exercise is counted.
- Tracks food and workouts by date.
- Saves your data in the browser with `localStorage`.
- Lets you delete individual foods or exercises, or clear either log.

## How the Code Is Organized

- `index.html` contains the app structure.
- `styles.css` controls the simple visual design.
- `app.js` stores the data, updates the display, and handles form actions.

## How to Build This Kind of App

1. Start with the data you need.

```js
let state = {
  goal: 2000,
  foods: [],
  exercises: [],
};
```

2. Add forms in HTML for the actions people can take.

```html
<form id="meal-form">
  <input id="food-name" name="food-name" />
  <input id="food-calories" name="food-calories" type="number" />
  <button>Add food</button>
</form>
```

3. Listen for form submissions in JavaScript.

```js
mealForm.addEventListener("submit", (event) => {
  event.preventDefault();
  addFood(name, calories);
});
```

4. Re-render the screen after each change.

```js
function render() {
  renderSummary();
  renderFoodList();
}
```

This pattern is the heart of many apps: keep data in one place, let users change it, then redraw the display from the latest data.

## Ideas to Build Next

- Add protein, carbs, and fat.
- Add meal categories like breakfast, lunch, dinner, and snacks.
- Add day detail popups from the calendar.
- Add default calorie estimates for common workouts.
- Connect the macro and workout helpers to a real AI/API service.
- Add a barcode scanner later with a nutrition API.
